#!/usr/bin/env python3
"""
0.0.9 Autotrainer daemon.

Polls cabinet_retrain.jsonl, builds a bounded mix (queued entities + fixed
anchors only), launches unguided_trainer.py as an isolated Metal subprocess,
gates on anchors + harvested queue, promotes, and writes status for the UI.

Never calls input(). Never runs beside a live App / train.py Metal process
in the same address space — the child is a separate process.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger("llm_gpu.autotrainer_daemon")

# Fixed anchors that must always be in the bounded mix
ANCHORS = [
    "What is the capital of France?",
    "Who invented the printing press?",
    "What is sequential layer streaming?",
]

DEFAULT_RETRAIN_LOG = Path("output/cabinet_retrain.jsonl")
DEFAULT_STATUS = Path("output/autotrainer_status.json")
DEFAULT_POLICY = Path("setup/unguided_v7_policy.json")
DEFAULT_RECIPE = Path("setup/chat_facts_v7_config.json")


def _load_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    rows = []
    with path.open() as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return rows


def _harvest_queue(retrain_log: Path, since_ts: str | None = None) -> list[dict]:
    """Return unique typed/canonical questions seen in the mismatch log."""
    rows = _load_jsonl(retrain_log)
    seen: set[str] = set()
    out: list[dict] = []
    for r in rows:
        if since_ts and r.get("ts", "") <= since_ts:
            continue
        key = r.get("canonical_question") or r.get("typed_question") or ""
        if key and key not in seen:
            seen.add(key)
            out.append(r)
    return out


def _build_bounded_mix_recipe(
    harvested: list[dict],
    base_recipe: Path,
    out_path: Path,
    unguarded: bool = False,
) -> Path:
    """
    Write a next-mix recipe that only includes:
    - the harvested queue entities
    - the fixed anchors
    Never rebuilds BPE in-process; the kernel will start fresh.
    """
    entities = []
    for h in harvested:
        q = h.get("canonical_question") or h.get("typed_question")
        if q:
            entities.append({"user": q, "source": "harvested"})
    for a in ANCHORS:
        entities.append({"user": a, "source": "anchor"})

    recipe = {
        "base_config": str(base_recipe),
        "entities": entities,
        "bounded": True,
        "unguarded": unguarded,
        "note": "Daemon-built bounded mix. Kernel must start in a fresh checkpoint dir.",
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(recipe, indent=2))
    return out_path


def _write_status(status_path: Path, payload: dict) -> None:
    status_path.parent.mkdir(parents=True, exist_ok=True)
    status_path.write_text(json.dumps(payload, indent=2))


def _run_kernel(
    config: Path,
    policy: Path,
    run_name: str,
    unguarded: bool = False,
    max_steps: int | None = None,
) -> int:
    """Launch unguided_trainer.py as a subprocess. Metal dies with the child."""
    cmd = [
        sys.executable,
        str(ROOT / "unguided_trainer.py"),
        "--config", str(config),
        "--policy", str(policy),
    ]
    if unguarded:
        cmd.append("--unguarded")
    if max_steps is not None:
        cmd.extend(["--max-steps", str(max_steps)])

    logger.info("Launching kernel: %s", " ".join(cmd))
    env = os.environ.copy()
    # Ensure child does not inherit an interactive flag
    env["LLM_NO_PROMPT"] = "1"
    proc = subprocess.run(cmd, cwd=str(ROOT), env=env)
    return proc.returncode


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="0.0.9 Autotrainer daemon")
    p.add_argument("--retrain-log", default=str(DEFAULT_RETRAIN_LOG))
    p.add_argument("--status", default=str(DEFAULT_STATUS))
    p.add_argument("--policy", default=str(DEFAULT_POLICY))
    p.add_argument("--recipe", default=str(DEFAULT_RECIPE))
    p.add_argument("--poll-s", type=float, default=30.0)
    p.add_argument("--once", action="store_true", help="Single harvest cycle then exit")
    p.add_argument("--unguarded", action="store_true")
    p.add_argument("--max-steps", type=int, default=None)
    p.add_argument("--dry-run", action="store_true")
    return p.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    retrain_log = Path(args.retrain_log)
    status_path = Path(args.status)
    policy_path = Path(args.policy)
    recipe_path = Path(args.recipe)

    last_ts: str | None = None
    cycle = 0

    while True:
        cycle += 1
        harvested = _harvest_queue(retrain_log, since_ts=last_ts)
        logger.info("Cycle %d | harvested=%d", cycle, len(harvested))

        if not harvested and not args.once:
            _write_status(status_path, {
                "state": "idle",
                "cycle": cycle,
                "harvested": 0,
                "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            })
            if args.dry_run:
                print("dry-run: nothing harvested, would sleep")
                return 0
            time.sleep(args.poll_s)
            continue

        # Update watermark
        if harvested:
            last_ts = max(h.get("ts", "") for h in harvested)

        run_name = f"daemon_cycle_{cycle:04d}"
        mix_recipe_path = Path("output/runs") / run_name / "bounded_mix_recipe.json"
        _build_bounded_mix_recipe(
            harvested, recipe_path, mix_recipe_path, unguarded=args.unguarded
        )

        _write_status(status_path, {
            "state": "training",
            "cycle": cycle,
            "harvested": len(harvested),
            "run_name": run_name,
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        })

        if args.dry_run:
            print(f"dry-run: would launch kernel for {run_name}")
            print(f"  mix recipe → {mix_recipe_path}")
            print(f"  harvested  → {len(harvested)}")
            return 0

        # Fresh policy copy with unique checkpoint dir (no resume across BPE)
        policy = json.loads(policy_path.read_text())
        policy["run_name"] = run_name
        policy["checkpoint_dir"] = f"output/checkpoints/{run_name}"
        policy["recipe"] = str(recipe_path)
        cycle_policy = Path("output/runs") / run_name / "policy.json"
        cycle_policy.parent.mkdir(parents=True, exist_ok=True)
        cycle_policy.write_text(json.dumps(policy, indent=2))

        rc = _run_kernel(
            config=recipe_path,
            policy=cycle_policy,
            run_name=run_name,
            unguarded=args.unguarded,
            max_steps=args.max_steps,
        )

        state = "promoted" if rc == 0 else "aborted"
        _write_status(status_path, {
            "state": state,
            "cycle": cycle,
            "harvested": len(harvested),
            "run_name": run_name,
            "exit_code": rc,
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        })
        logger.info("Kernel finished rc=%d state=%s", rc, state)

        if args.once:
            return rc

        time.sleep(args.poll_s)


if __name__ == "__main__":
    sys.exit(main())
