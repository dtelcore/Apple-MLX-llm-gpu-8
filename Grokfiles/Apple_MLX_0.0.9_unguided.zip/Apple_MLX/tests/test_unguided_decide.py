"""Unit tests for the pure decide() engine. No Metal required."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from training.unguided.decide import decide, DecideContext, Decision


def _ctx(**kwargs) -> DecideContext:
    base = dict(
        step=100,
        max_steps=500,
        wall_s=60.0,
        max_wall_s=7200.0,
        val_loss=0.9,
        best_val_loss=1.0,
        recent_val_losses=[1.1, 1.0, 0.95],
        nan_detected=False,
        cabinet_exact_match=0.5,
        policy={
            "loss_spike_ratio": 2.0,
            "early_stop_patience": 4,
            "remix_if": {
                "cabinet_exact_match_below": 0.15,
                "after_steps": 50,
            },
        },
        no_improvement_count=0,
    )
    base.update(kwargs)
    return DecideContext(**base)


def test_nan_aborts():
    r = decide(_ctx(nan_detected=True))
    assert r.action == Decision.ABORT_SPIKE
    assert "non_finite" in r.reason or "nan" in r.reason.lower() or r.reason == "non_finite_loss"


def test_spike_aborts():
    r = decide(_ctx(val_loss=3.0, recent_val_losses=[1.0, 1.1, 0.9]))
    assert r.action == Decision.ABORT_SPIKE
    assert "spike" in r.reason


def test_promote_on_best():
    r = decide(_ctx(val_loss=0.8, best_val_loss=1.0))
    assert r.action == Decision.PROMOTE
    assert r.promote is True


def test_continue_when_ok():
    r = decide(_ctx(val_loss=1.05, best_val_loss=1.0, no_improvement_count=1))
    assert r.action == Decision.CONTINUE
    assert r.promote is False


def test_early_stop_on_patience():
    r = decide(_ctx(no_improvement_count=4, val_loss=1.05, best_val_loss=1.0))
    assert r.action == Decision.EARLY_STOP


def test_remix_abort():
    r = decide(_ctx(
        step=100,
        cabinet_exact_match=0.05,
        policy={
            "loss_spike_ratio": 2.0,
            "early_stop_patience": 4,
            "remix_if": {"cabinet_exact_match_below": 0.15, "after_steps": 50},
            "recipe": "setup/chat_facts_v7_config.json",
        },
    ))
    assert r.action == Decision.ABORT_REMIX
    assert r.next_mix_recipe is not None
    assert "suggested_cmd" in r.next_mix_recipe


def test_max_steps():
    r = decide(_ctx(step=500, max_steps=500))
    assert r.action == Decision.STOP_LIMIT
    assert "max_steps" in r.reason


def test_wall_clock():
    r = decide(_ctx(wall_s=8000, max_wall_s=7200))
    assert r.action == Decision.STOP_LIMIT
    assert "max_wall_s" in r.reason


if __name__ == "__main__":
    test_nan_aborts()
    test_spike_aborts()
    test_promote_on_best()
    test_continue_when_ok()
    test_early_stop_on_patience()
    test_remix_abort()
    test_max_steps()
    test_wall_clock()
    print("all decide tests passed")
