# Changelog

## 0.0.9 — 2026-09-13

### Added
- **Unguided trainer kernel** (`unguided_trainer.py`)
  - Fully non-interactive: never calls `input()`, forces `no_prompt=True`.
  - Loads existing recipe JSON + new policy JSON (`setup/unguided_v7_policy.json`).
  - Decision engine (`training/unguided/decide.py`): continue / promote / early_stop / abort_spike / abort_remix / stop_limit.
  - Remix decision aborts, writes `ABORT_REASON` + `NEXT_MIX.json`, exits non-zero. Never changes BPE mid-flight.
  - Dry-run mode prints plan and exits 0 with no Metal init.
  - `--unguarded` relaxes data hygiene only; hard limits (NaN, spike, wall, vocab mismatch) stay enforced.
- **Autotrainer daemon** (`autotrainer_daemon.py`)
  - Polls `output/cabinet_retrain.jsonl`.
  - Builds bounded mix (harvested queue + fixed anchors only).
  - Launches kernel as isolated Metal subprocess.
  - Writes `output/autotrainer_status.json` for the UI.
  - Each cycle uses a fresh checkpoint directory (no `--resume` across BPE).
- Library primitives under `training/unguided/`:
  - `session.py` — `build_train_session` (refuses v6/v4-looking dirs, vocab fingerprint)
  - `loop.py` — `train_segment`
  - `eval_suite.py` — val loss + router fixture (no second Metal process, no Q/K cosine yet)
- Unit tests for `decide()` (`tests/test_unguided_decide.py`).

### Not changed
- `auto_train.py`, `train.py`, `App.py` remain exactly as they were.
- No chat hot-reload. No `models/v8_active.ckpt`. No hard 0.92 / cosine gates on day one.

### Invariants preserved
- No mid-run remix that mutates tokenizer.
- No second Metal process in the same address space.
- Promote only under `output/checkpoints/`.
