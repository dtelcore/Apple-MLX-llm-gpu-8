"""
Eval suite for unguided runs.

(a) existing evaluate_val_loss
(b) router-only fixture (no extra Metal process)
(c) optional teacher-forced ranks on a small labeled subset using the
    already-loaded model (no second checkpoint load)

Q/K cosine and attention entropy are intentionally skipped in v0.0.9.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import logging
import math

logger = logging.getLogger("llm_gpu.unguided")


@dataclass
class EvalResults:
    val_loss: float | None
    val_ppl: float | None
    cabinet_exact_match: float | None
    cabinet_n: int = 0
    router_precision: float | None = None
    router_recall: float | None = None
    nan_detected: bool = False


def run_eval_suite(session: Any, policy: dict) -> EvalResults:
    """
    Run the three lightweight evals. Never launches a second Metal process.
    """
    val_loss = None
    val_ppl = None
    nan = False

    # (a) val loss – reuse existing helper
    try:
        from training.eval import evaluate_val_loss  # type: ignore
        vr = evaluate_val_loss(session.model, session.val_loader, session.args)
        val_loss = float(vr.get("loss", float("nan")))
        val_ppl = float(vr.get("ppl", math.exp(min(val_loss or 20, 20))))
        if not math.isfinite(val_loss):
            nan = True
    except Exception as e:
        logger.warning("evaluate_val_loss failed: %s", e)
        val_loss = None

    # (b) router-only fixture (observational)
    cabinet_exact = None
    cabinet_n = 0
    router_prec = None
    router_rec = None
    fixture = Path("data/cabinet_binding_eval.jsonl")
    try:
        from tools.eval_cabinet_bindings import eval_router_fixture  # type: ignore
        if fixture.exists():
            rr = eval_router_fixture(
                fixture_path=fixture,
                model=session.model,
                tokenizer=session.tokenizer,
                args=session.args,
            )
            cabinet_exact = rr.get("exact_match")
            cabinet_n = int(rr.get("n", 0))
            router_prec = rr.get("precision")
            router_rec = rr.get("recall")
    except Exception as e:
        logger.warning("router fixture eval skipped: %s", e)

    return EvalResults(
        val_loss=val_loss,
        val_ppl=val_ppl,
        cabinet_exact_match=cabinet_exact,
        cabinet_n=cabinet_n,
        router_precision=router_prec,
        router_recall=router_rec,
        nan_detected=nan,
    )
