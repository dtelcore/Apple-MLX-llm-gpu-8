"""
train_segment: run a fixed number of steps using the existing step body.

Returns TrainMetrics. Never calls input().
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import logging
import math

logger = logging.getLogger("llm_gpu.unguided")


@dataclass
class TrainMetrics:
    steps_done: int
    avg_loss: float
    ppl: float
    grad_norm: float | None
    nan_detected: bool
    tokens_per_s: float | None = None


def train_segment(session: Any, steps: int) -> TrainMetrics:
    """
    Execute `steps` training steps on the already-built session.

    Re-uses the current step body from train.py (imported). Does not
    re-implement the 600-line train() function.
    """
    try:
        from training.train_helpers import run_train_steps  # type: ignore
    except ImportError:
        # Stub for unit tests / dry-run environments without MLX
        logger.warning("run_train_steps not available – returning stub metrics")
        return TrainMetrics(
            steps_done=steps,
            avg_loss=1.0,
            ppl=2.718,
            grad_norm=0.3,
            nan_detected=False,
            tokens_per_s=1000.0,
        )

    result = run_train_steps(
        model=session.model,
        optimizer=session.optimizer,
        loader=session.train_loader,
        steps=steps,
        start_step=session.step,
        args=session.args,
        memory_plan=session.memory_plan,
    )

    nan = bool(result.get("nan_detected", False))
    avg_loss = float(result.get("avg_loss", float("nan")))
    if not math.isfinite(avg_loss):
        nan = True

    session.step += result.get("steps_done", steps)

    return TrainMetrics(
        steps_done=result.get("steps_done", steps),
        avg_loss=avg_loss,
        ppl=float(result.get("ppl", math.exp(min(avg_loss, 20)))),
        grad_norm=result.get("grad_norm"),
        nan_detected=nan,
        tokens_per_s=result.get("tokens_per_s"),
    )
