"""
TrainSession wrapper.

Forces no_prompt=True and refuses interactive paths.
Does not copy the 600-line train() body; it re-uses the existing
construction helpers that train.py already calls.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional
import json
import hashlib
import logging

logger = logging.getLogger("llm_gpu.unguided")


@dataclass
class TrainSession:
    """Opaque handle holding tokenizer, model, optimizer, datasets, memory plan."""
    args: Any
    tokenizer: Any
    model: Any
    optimizer: Any
    train_loader: Any
    val_loader: Any
    memory_plan: Any
    checkpoint_dir: Path
    run_dir: Path
    vocab_fingerprint: str
    dataset_path: str
    step: int = 0
    best_val_loss: float | None = None
    recent_val_losses: list[float] = field(default_factory=list)
    no_improvement_count: int = 0
    start_wall: float = 0.0

    def wall_s(self) -> float:
        import time
        return time.time() - self.start_wall


def _fingerprint_vocab(tokenizer) -> str:
    """Stable hash of vocab so we can refuse cross-BPE resume."""
    try:
        # Prefer an explicit vocab file if present
        if hasattr(tokenizer, "get_vocab"):
            vocab = tokenizer.get_vocab()
            raw = json.dumps(sorted(vocab.items()), sort_keys=True).encode()
        elif hasattr(tokenizer, "vocab"):
            raw = json.dumps(tokenizer.vocab, sort_keys=True).encode()
        else:
            raw = str(type(tokenizer)).encode()
        return hashlib.sha256(raw).hexdigest()[:16]
    except Exception:
        return "unknown"


def build_train_session(args, policy: dict) -> TrainSession:
    """
    Construct everything needed for training without ever calling input().

    - Forces args.no_prompt = True
    - Refuses to open a checkpoint dir that looks like a v6/v4 resume when policy says so
    - Computes vocab fingerprint for later mismatch checks
    """
    # Hard non-interactive
    if hasattr(args, "no_prompt"):
        args.no_prompt = True
    if hasattr(args, "menu"):
        args.menu = False

    checkpoint_dir = Path(policy.get("checkpoint_dir", "output/checkpoints/unguided_v7"))
    run_name = policy.get("run_name", "unguided_v7")
    run_dir = Path("output/runs") / run_name
    run_dir.mkdir(parents=True, exist_ok=True)

    # Refuse dangerous resume targets
    hard = policy.get("hard_limits", {})
    if hard.get("refuse_existing_v6_v4_dir", True):
        name = checkpoint_dir.name.lower()
        if any(x in name for x in ("v6", "v4", "chat_facts_v6", "chat_facts_v4")):
            raise RuntimeError(
                f"Refusing to use checkpoint dir that looks like a v6/v4 resume: {checkpoint_dir}. "
                "Unguided runs must start in a fresh directory."
            )

    # Import existing construction helpers (the real project ones).
    # These are the same functions train.py already uses; we do not re-implement them.
    try:
        from training.train_helpers import (  # type: ignore
            build_tokenizer,
            build_model,
            build_optimizer,
            build_dataloaders,
            plan_memory,
        )
    except ImportError:
        # Fallback stubs so the module is importable in isolation / tests
        logger.warning("train_helpers not found – using stubs (tests / dry-run only)")
        build_tokenizer = lambda a: None
        build_model = lambda a, t: None
        build_optimizer = lambda m, a: None
        build_dataloaders = lambda a, t: (None, None)
        plan_memory = lambda a, m: None

    tokenizer = build_tokenizer(args)
    model = build_model(args, tokenizer)
    optimizer = build_optimizer(model, args)
    train_loader, val_loader = build_dataloaders(args, tokenizer)
    memory_plan = plan_memory(args, model)

    vocab_fp = _fingerprint_vocab(tokenizer)
    dataset_path = getattr(args, "dataset", None) or getattr(args, "data", "") or ""

    # Optional: refuse resume when fingerprint disagrees
    if hard.get("refuse_resume_on_vocab_mismatch", True) and checkpoint_dir.exists():
        meta = checkpoint_dir / "unguided_meta.json"
        if meta.exists():
            prev = json.loads(meta.read_text())
            if prev.get("vocab_fingerprint") and prev["vocab_fingerprint"] != vocab_fp:
                raise RuntimeError(
                    f"Vocab fingerprint mismatch: checkpoint has {prev['vocab_fingerprint']}, "
                    f"current recipe has {vocab_fp}. Refusing --resume across BPE change."
                )

    import time
    session = TrainSession(
        args=args,
        tokenizer=tokenizer,
        model=model,
        optimizer=optimizer,
        train_loader=train_loader,
        val_loader=val_loader,
        memory_plan=memory_plan,
        checkpoint_dir=checkpoint_dir,
        run_dir=run_dir,
        vocab_fingerprint=vocab_fp,
        dataset_path=str(dataset_path),
        start_wall=time.time(),
    )

    # Write meta so future launches can detect mismatch
    meta_path = checkpoint_dir / "unguided_meta.json"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    meta_path.write_text(json.dumps({
        "vocab_fingerprint": vocab_fp,
        "dataset_path": session.dataset_path,
        "policy_recipe": policy.get("recipe"),
        "run_name": run_name,
    }, indent=2))

    return session
