"""Unguided (non-interactive) training loop for 0.0.9+."""

from .decide import decide, Decision
from .session import build_train_session, TrainSession
from .loop import train_segment, TrainMetrics
from .eval_suite import run_eval_suite, EvalResults

__all__ = [
    "decide",
    "Decision",
    "build_train_session",
    "TrainSession",
    "train_segment",
    "TrainMetrics",
    "run_eval_suite",
    "EvalResults",
]
