#!/usr/bin/env python3
"""
0.0.9 Unguided (non-interactive) trainer kernel.

Never calls input(). Never prompts. Aborts cleanly on remix / NaN / spike.
Does not --resume across a BPE change.

Usage:
  python unguided_trainer.py --config setup/chat_facts_v7_config.json --policy setup/unguided_v7_policy.json
  python unguided_trainer.py --config ... --policy ... --dry-run
  python unguided_trainer.py --config ... --policy ... --unguarded
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import time
from pathlib import Path

# Ensure project root is on path when run as script
ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger("llm_gpu.unguided")


def _load_json(path: Path) -> dict:
    with path.open() as f:
        return json.load(f)


def _append_decision(run_dir: Path, record: dict) -> None:
    run_dir.mkdir(parents=True, exist_ok=True)
    path = run_dir / "decisions.jsonl"
    with path.open("a") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def _write_abort(run_dir: Path, reason: str, next_mix: dict | None = None) -> None:
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "ABORT_REASON").write_text(reason + "\n")
    if next_mix is not None:
        (run_dir / "NEXT_MIX.json").write_text(json.dumps(next_mix, indent=2) + "\n")


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="0.0.9 Unguided trainer (no input())")
    p.add_argument("--config", required=True, help="Recipe JSON (setup/*.json)")
    p.add_argument("--policy", required=True, help="Policy JSON (setup/unguided_*_policy.json)")
    p.add_argument("--dry-run", action="store_true", help="Print plan and exit 0, no Metal")
    p.add_argument("--unguarded", action="store_true",
                   help="Relax data hygiene only; hard limits still enforced")
    p.add_argument("--max-steps", type=int, default=None, help="Override policy max_steps")
    p.add_argument("--eval-every", type=int, default=None, help="Override policy eval_every")
    return p.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    config_path = Path(args.config)
    policy_path = Path(args.policy)

    if not config_path.exists():
        logger.error("Recipe not found: %s", config_path)
        return 2
    if not policy_path.exists():
        logger.error("Policy not found: %s", policy_path)
        return 2

    recipe = _load_json(config_path)
    policy = _load_json(policy_path)

    # CLI overrides
    if args.max_steps is not None:
        policy["max_steps"] = args.max_steps
    if args.eval_every is not None:
        policy["eval_every"] = args.eval_every
    if args.unguarded:
        policy["unguarded"] = True

    run_name = policy.get("run_name", "unguided_v7")
    run_dir = Path("output/runs") / run_name
    max_steps = int(policy.get("max_steps", 500))
    eval_every = int(policy.get("eval_every", 50))
    max_wall_s = float(policy.get("max_wall_s", 7200))

    # ---- dry-run ----------------------------------------------------------
    if args.dry_run:
        print("=== UNGUIDED DRY-RUN ===")
        print(f"recipe:        {config_path}")
        print(f"policy:        {policy_path}")
        print(f"run_name:      {run_name}")
        print(f"checkpoint:    {policy.get('checkpoint_dir')}")
        print(f"max_steps:     {max_steps}")
        print(f"eval_every:    {eval_every}")
        print(f"max_wall_s:    {max_wall_s}")
        print(f"early_stop:    patience={policy.get('early_stop_patience')}")
        print(f"loss_spike:    ratio={policy.get('loss_spike_ratio')}")
        print(f"remix_if:      {policy.get('remix_if')}")
        print(f"unguarded:     {bool(args.unguarded)}")
        print("No Metal init. Exiting 0.")
        return 0

    # ---- real run ---------------------------------------------------------
    # Build a minimal namespace that existing helpers expect.
    # Force no_prompt so nothing can ever call input().
    from types import SimpleNamespace
    train_args = SimpleNamespace(
        **recipe,
        no_prompt=True,
        menu=False,
        unguarded=bool(args.unguarded),
        config=str(config_path),
    )

    from training.unguided.session import build_train_session
    from training.unguided.loop import train_segment
    from training.unguided.eval_suite import run_eval_suite
    from training.unguided.decide import decide, DecideContext, Decision

    try:
        session = build_train_session(train_args, policy)
    except RuntimeError as e:
        logger.error("Session build refused: %s", e)
        _write_abort(run_dir, str(e))
        return 1

    logger.info("Unguided session ready | run=%s | vocab_fp=%s | ckpt=%s",
                run_name, session.vocab_fingerprint, session.checkpoint_dir)

    # Optional promote helper
    try:
        from training.checkpoint import promote_best  # type: ignore
    except ImportError:
        def promote_best(ckpt_dir, metric, value):  # type: ignore
            logger.info("promote_best stub: %s = %s", metric, value)

    history: list[float] = []
    start = time.time()

    while True:
        # 1. Train segment
        metrics = train_segment(session, eval_every)
        logger.info("segment done | step=%d loss=%.4f nan=%s",
                    session.step, metrics.avg_loss, metrics.nan_detected)

        # 2. Eval
        eval_res = run_eval_suite(session, policy)
        if eval_res.val_loss is not None:
            history.append(eval_res.val_loss)
            window = int(policy.get("loss_median_window", 5))
            session.recent_val_losses = history[-window:]

        # 3. Decide
        ctx = DecideContext(
            step=session.step,
            max_steps=max_steps,
            wall_s=time.time() - start,
            max_wall_s=max_wall_s,
            val_loss=eval_res.val_loss,
            best_val_loss=session.best_val_loss,
            recent_val_losses=session.recent_val_losses,
            nan_detected=metrics.nan_detected or eval_res.nan_detected,
            cabinet_exact_match=eval_res.cabinet_exact_match,
            policy=policy,
            no_improvement_count=session.no_improvement_count,
        )
        result = decide(ctx)

        # Update improvement tracking
        if eval_res.val_loss is not None:
            if session.best_val_loss is None or eval_res.val_loss < session.best_val_loss:
                session.best_val_loss = eval_res.val_loss
                session.no_improvement_count = 0
            else:
                session.no_improvement_count += 1

        # Log decision
        rec = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "step": session.step,
            "action": result.action.value,
            "reason": result.reason,
            "val_loss": eval_res.val_loss,
            "cabinet_exact_match": eval_res.cabinet_exact_match,
            "promote": result.promote,
        }
        _append_decision(run_dir, rec)
        logger.info("decision=%s reason=%s", result.action.value, result.reason)

        # 4. Act
        if result.promote:
            promote_best(session.checkpoint_dir, "val_loss", session.best_val_loss)

        if result.action in (Decision.CONTINUE, Decision.PROMOTE):
            continue

        if result.action == Decision.ABORT_REMIX:
            _write_abort(run_dir, result.reason, result.next_mix_recipe)
            logger.warning("ABORT_REMIX: %s", result.reason)
            return 1

        if result.action == Decision.ABORT_SPIKE:
            _write_abort(run_dir, result.reason)
            logger.error("ABORT_SPIKE: %s", result.reason)
            return 1

        if result.action in (Decision.EARLY_STOP, Decision.STOP_LIMIT):
            _write_abort(run_dir, result.reason)
            logger.info("Stopping: %s", result.reason)
            # Write summary
            summary = {
                "final_step": session.step,
                "best_val_loss": session.best_val_loss,
                "action": result.action.value,
                "reason": result.reason,
            }
            (run_dir / "summary.json").write_text(json.dumps(summary, indent=2))
            return 0

        # Safety: unknown action
        _write_abort(run_dir, f"unknown_action:{result.action}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
