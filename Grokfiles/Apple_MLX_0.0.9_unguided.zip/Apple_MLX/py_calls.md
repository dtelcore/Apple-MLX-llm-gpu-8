# Entry points (0.0.9)

| Script | Role | Interactive? |
|--------|------|--------------|
| `unguided_trainer.py` | Unattended train/eval/decide kernel | **No** — never calls `input()` |
| `autotrainer_daemon.py` | Harvest mismatches → bounded mix → spawn kernel → status | **No** |
| `train.py` | Guided / menu / quality-trial (unchanged) | Yes |
| `auto_train.py` | Train-then-smoke (unchanged) | Prompts unless `--no-prompt` |
| `App.py` | Web UI + inspector (unchanged) | Yes |

## Unguided examples

```bash
# Dry-run (no Metal)
python unguided_trainer.py \
  --config setup/chat_facts_v7_config.json \
  --policy setup/unguided_v7_policy.json \
  --dry-run

# Short guarded run into a fresh dir
python unguided_trainer.py \
  --config setup/chat_facts_v7_config.json \
  --policy setup/unguided_v7_policy.json \
  --max-steps 50

# Daemon single cycle
python autotrainer_daemon.py --once --dry-run
```
